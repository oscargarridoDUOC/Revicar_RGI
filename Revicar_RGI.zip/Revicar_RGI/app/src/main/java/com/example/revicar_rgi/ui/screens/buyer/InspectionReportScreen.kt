package com.example.revicar_rgi.ui.screens.buyer

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.revicar_rgi.ui.viewmodel.InspectionDetailViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InspectionReportScreen(
    inspectionId: String,
    viewModel: InspectionDetailViewModel,
    navController: NavController
) {
    val ui by viewModel.uiState.collectAsState()

    LaunchedEffect(inspectionId) { viewModel.load(inspectionId) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Informe de Inspección") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = null)
                    }
                }
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            if (ui.isLoading && ui.photos.isEmpty()) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(16.dp))
            }

            if (ui.photos.isEmpty()) {
                Text("No hay fotos asociadas a esta inspección.")
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(ui.photos) { photo ->
                        Card {
                            Column(Modifier.padding(12.dp)) {
                                AsyncImage(
                                    model = photo.imageUrl,
                                    contentDescription = null,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(200.dp)
                                )
                                Spacer(Modifier.height(8.dp))
                                Text(photo.description)
                            }
                        }
                    }
                }
            }
        }
    }
}
