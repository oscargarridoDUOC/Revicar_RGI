package com.example.revicar_rgi.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.revicar_rgi.data.model.InspectionDetailUiState
import com.example.revicar_rgi.data.repository.AuthRepository
import com.example.revicar_rgi.data.repository.InspectionRepository
import com.example.revicar_rgi.data.repository.PhotoRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class InspectionDetailViewModel(
    private val inspectionRepository: InspectionRepository = InspectionRepository(),
    private val authRepository: AuthRepository = AuthRepository(),
    private val photoRepository: PhotoRepository = PhotoRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(InspectionDetailUiState())
    val uiState: StateFlow<InspectionDetailUiState> = _uiState.asStateFlow()

    fun load(inspectionId: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            authRepository.getUser()

            inspectionRepository.listenInspection(inspectionId)
                .catch { e -> _uiState.update { it.copy(isLoading = false, error = e.message) } }
                .onEach { inspection ->
                    _uiState.update { it.copy(inspection = inspection, isLoading = false) }
                }
                .launchIn(this)

            photoRepository.listenPhotos(inspectionId)
                .catch { e -> _uiState.update { it.copy(uploadError = e.message) } }
                .onEach { photos ->
                    _uiState.update { it.copy(photos = photos) }
                }
                .launchIn(this)
        }
    }

    fun uploadPhoto(inspectionId: String, uri: Uri, description: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isUploading = true, uploadError = null) }
            try {
                photoRepository.uploadPhoto(inspectionId, uri, description)
                _uiState.update { it.copy(isUploading = false) }
            } catch (e: Exception) {
                _uiState.update { it.copy(isUploading = false, uploadError = e.message) }
            }
        }
    }

    suspend fun finalizeInspection(inspectionId: String) {
        inspectionRepository.updateStatus(inspectionId, "FINALIZADO")
        _uiState.update { it.copy(actionSuccess = true) }
    }

    class Factory(
        private val inspectionRepository: InspectionRepository,
        private val authRepository: AuthRepository
    ) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            @Suppress("UNCHECKED_CAST")
            return InspectionDetailViewModel(inspectionRepository, authRepository) as T
        }
    }
}
