package com.example.revicar_rgi.ui.screens.mechanic

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.revicar_rgi.data.model.Inspection
import com.example.revicar_rgi.ui.viewmodel.InspectionDetailViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MechanicInspectionDetailScreen(
    inspectionId: String,
    viewModel: InspectionDetailViewModel,
    navController: NavController
) {
    val ui by viewModel.uiState.collectAsState()
    val scope = rememberCoroutineScope()

    LaunchedEffect(inspectionId) { viewModel.load(inspectionId) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Detalle del Trabajo") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = null)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            ui.inspection?.let { inspection ->
                Text("Datos del trabajo", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Text("Fecha/Hora: ${inspection.dateMillis} - ${inspection.time}")
                Text("Cliente: ${inspection.userId}")
                Text("Dirección: ${inspection.direccion}, ${inspection.comuna}")
                Spacer(Modifier.height(16.dp))

                when (inspection.status) {
                    "ACEPTADO" -> {
                        PhotoUploaderSection(
                            inspection = inspection,
                            viewModel = viewModel
                        )

                        Spacer(Modifier.height(16.dp))
                        Button(
                            onClick = {
                                if (ui.photos.isNotEmpty()) {
                                    scope.launch { viewModel.finalizeInspection(inspection.id) }
                                }
                            },
                            enabled = ui.photos.isNotEmpty(),
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Finalizar Inspección") }
                    }

                    "PENDIENTE" -> {
                        Text(
                            "Debes aceptar el trabajo para subir fotos.",
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    "FINALIZADO" -> {
                        Text(
                            "Este trabajo ya ha sido finalizado.",
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PhotoUploaderSection(
    inspection: Inspection,
    viewModel: InspectionDetailViewModel
) {
    val ui by viewModel.uiState.collectAsState()
    var tempDescription by remember { mutableStateOf("") }
    var tempUri by remember { mutableStateOf<Uri?>(null) }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri -> tempUri = uri }
    )

    Text("Evidencia fotográfica", style = MaterialTheme.typography.titleMedium)
    Spacer(Modifier.height(8.dp))

    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = {
            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }) { Text("Seleccionar foto") }

        if (ui.isUploading) {
            CircularProgressIndicator(modifier = Modifier.size(24.dp))
        }
    }

    // Vista previa de la foto seleccionada y campo de descripción
    if (tempUri != null) {
        Spacer(Modifier.height(8.dp))
        AsyncImage(
            model = tempUri,
            contentDescription = null,
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .clip(RoundedCornerShape(12.dp))
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = tempDescription,
            onValueChange = { tempDescription = it },
            label = { Text("Descripción de la foto") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = {
                tempUri?.let { uri ->
                    viewModel.uploadPhoto(inspection.id, uri, tempDescription.trim())
                    tempUri = null
                    tempDescription = ""
                }
            },
            enabled = !ui.isUploading && tempDescription.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) { Text("Subir foto") }
    }

    Spacer(Modifier.height(16.dp))
    Text("Fotos subidas", style = MaterialTheme.typography.titleMedium)
    Spacer(Modifier.height(8.dp))
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items(ui.photos) { photo ->
            Card {
                Column(Modifier.padding(12.dp)) {
                    AsyncImage(
                        model = photo.imageUrl,
                        contentDescription = null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(12.dp))
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(photo.description)
                }
            }
        }
    }
}
