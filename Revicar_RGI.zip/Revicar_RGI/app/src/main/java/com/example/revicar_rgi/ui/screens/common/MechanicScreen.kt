package com.example.revicar_rgi.ui.screens.common

data class Inspection(
    val id: String = "",
    val title: String = "",
    val description: String = ""
)