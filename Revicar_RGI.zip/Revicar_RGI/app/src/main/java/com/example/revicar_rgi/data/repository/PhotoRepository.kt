package com.example.revicar_rgi.data.repository

import android.net.Uri
import com.example.revicar_rgi.data.model.InspectionPhoto
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.firestore
import com.google.firebase.storage.storage
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.UUID

class PhotoRepository {
    private val auth = Firebase.auth
    private val db = Firebase.firestore
    private val storage = Firebase.storage

    suspend fun uploadPhoto(
        inspectionId: String,
        localUri: Uri,
        description: String
    ): InspectionPhoto {
        val photoId = UUID.randomUUID().toString()
        val storageRef = storage.reference
            .child("inspections/$inspectionId/$photoId.jpg")

        storageRef.putFile(localUri).await()

        val downloadUrl = storageRef.downloadUrl.await().toString()

        val docRef = db.collection("inspections")
            .document(inspectionId)
            .collection("photos")
            .document(photoId)

        val photo = InspectionPhoto(
            id = photoId,
            inspectionId = inspectionId,
            imageUrl = downloadUrl,
            description = description,
            takenByUserId = auth.currentUser?.uid.orEmpty()
        )

        docRef.set(photo).await()
        return photo
    }

    fun listenPhotos(inspectionId: String): Flow<List<InspectionPhoto>> = callbackFlow {
        val ref = db.collection("inspections")
            .document(inspectionId)
            .collection("photos")
            .orderBy("timestamp", Query.Direction.DESCENDING)

        val listener = ref.addSnapshotListener { snap, err ->
            if (err != null) {
                close(err); return@addSnapshotListener
            }
            val list = snap?.toObjects(InspectionPhoto::class.java) ?: emptyList()
            trySend(list)
        }

        awaitClose { listener.remove() }
    }
}
