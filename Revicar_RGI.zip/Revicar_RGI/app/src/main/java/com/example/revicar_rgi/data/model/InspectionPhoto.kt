package com.example.revicar_rgi.data.model

import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.ServerTimestamp
import java.util.Date

data class InspectionPhoto(
    @DocumentId val id: String = "",
    val inspectionId: String = "",
    val imageUrl: String = "",
    val description: String = "",
    val takenByUserId: String = "",
    @ServerTimestamp val timestamp: Date? = null
)
