package com.example.revicar_rgi.ui.screens.mechanic

import android.Manifest
import android.content.Context
import android.net.Uri
import android.os.Build
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import coil.compose.rememberAsyncImagePainter
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.*



@Composable
fun TakePhotoScreen(
    inspectionId: String,
    onBack: () -> Unit = {}
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val coroutineScope = rememberCoroutineScope()

    var hasCameraPermission by remember { mutableStateOf(false) }
    var imageCapture: ImageCapture? by remember { mutableStateOf(null) }
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var description by remember { mutableStateOf(TextFieldValue("")) }
    var uploading by remember { mutableStateOf(false) }
    var uploadMessage by remember { mutableStateOf("") }


    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> hasCameraPermission = granted }

    LaunchedEffect(Unit) {
        cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .background(MaterialTheme.colorScheme.background),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "Registro del trabajo",
            style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        if (hasCameraPermission) {
            val cameraProviderFuture = remember { ProcessCameraProvider.getInstance(context) }
            val previewView = remember { PreviewView(context) }

            LaunchedEffect(Unit) {
                val cameraProvider = cameraProviderFuture.get()
                val preview = androidx.camera.core.Preview.Builder().build().also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }
                imageCapture = ImageCapture.Builder().build()
                val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

                try {
                    cameraProvider.unbindAll()
                    cameraProvider.bindToLifecycle(
                        lifecycleOwner,
                        cameraSelector,
                        preview,
                        imageCapture
                    )
                } catch (e: Exception) {
                    Log.e("CameraX", "Error binding camera use cases", e)
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
            ) {
                if (imageUri == null) {
                    AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
                } else {
                    Image(
                        painter = rememberAsyncImagePainter(imageUri),
                        contentDescription = "Foto tomada",
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    val file = createPhotoFile(context)
                    val outputOptions = ImageCapture.OutputFileOptions.Builder(file).build()
                    imageCapture?.takePicture(
                        outputOptions,
                        ContextCompat.getMainExecutor(context),
                        object : ImageCapture.OnImageSavedCallback {
                            override fun onError(exc: ImageCaptureException) {
                                Log.e("CameraX", "Error capturando foto: ${exc.message}", exc)
                            }

                            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                                imageUri = Uri.fromFile(file)
                            }
                        }
                    )
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (imageUri == null) "Tomar Foto" else "Repetir Foto")
            }

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Descripción del trabajo") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    if (imageUri != null && description.text.isNotEmpty()) {
                        coroutineScope.launch {
                            uploading = true
                            uploadMessage = "Subiendo..."
                            uploadPhotoToFirebase(
                                context,
                                inspectionId,
                                imageUri!!,
                                description.text,
                                onComplete = { success, msg ->
                                    uploading = false
                                    uploadMessage = msg
                                    if (success) onBack()
                                }
                            )
                        }
                    }
                },
                enabled = imageUri != null && description.text.isNotEmpty() && !uploading,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (uploading) "Subiendo..." else "Guardar en Firebase")
            }

            if (uploadMessage.isNotEmpty()) {
                Text(uploadMessage, modifier = Modifier.padding(top = 8.dp))
            }

        } else {
            Text("Permiso de cámara denegado.")
            Spacer(modifier = Modifier.height(8.dp))
            Button(onClick = { cameraPermissionLauncher.launch(Manifest.permission.CAMERA) }) {
                Text("Conceder permiso")
            }
        }
    }
}

private fun createPhotoFile(context: Context): File {
    val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
    val fileName = "mecanico_$timestamp.jpg"
    val storageDir = context.getExternalFilesDir(null)
    return File(storageDir, fileName)
}

private fun uploadPhotoToFirebase(
    context: Context,
    inspectionId: String,
    imageUri: Uri,
    description: String,
    onComplete: (Boolean, String) -> Unit
) {
    val storage = FirebaseStorage.getInstance()
    val firestore = FirebaseFirestore.getInstance()
    val user = FirebaseAuth.getInstance().currentUser

    val fileName = "mechanic_photos/${UUID.randomUUID()}.jpg"
    val storageRef = storage.reference.child(fileName)

    val uploadTask = storageRef.putFile(imageUri)
    uploadTask.addOnSuccessListener {
        val addOnFailureListener = storageRef.downloadUrl.addOnSuccessListener { uri ->
            val photoUrl = uri.toString()

            val updateData = mapOf(
                "mechanicPhotoUrl" to photoUrl,
                "mechanicDescription" to description,
                "mechanicId" to (user?.uid ?: "unknown"),
                "updatedAt" to Date()
            )

            firestore.collection("inspections").document(inspectionId)
                .update(updateData)
                .addOnSuccessListener {
                    onComplete(true, "Foto y descripción guardadas correctamente.")
                }
                .addOnFailureListener { e ->
                    onComplete(false, "Error guardando en Firestore: ${e.message}")
                }

        }.addOnFailureListener {
            onComplete(false, "Error obteniendo URL: ${it.message}")
        }
        addOnFailureListener
    }.addOnFailureListener {
        onComplete(false, "Error subiendo foto: ${it.message}")
    }
}






